import { FeatureCollection } from 'geojson';

export interface KMLStats {
  Placemark: number;
  Point: number;
  LineString: number;
  Polygon: number;
  MultiGeometry: number;
}

export interface DetailedStats extends KMLStats {
  totalLength: number;
  totalArea: number;
  boundingBox: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
}

export interface MapState {
  geoJson: FeatureCollection | null;
  stats: KMLStats | null;
  detailedStats: DetailedStats | null;
  error: string | null;
}