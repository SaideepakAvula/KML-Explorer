import React, { useMemo, useEffect } from 'react';
import { MapContainer, TileLayer, GeoJSON, Tooltip, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { FeatureCollection, Feature, Position } from 'geojson';

// Helper component to update map view
const MapUpdater: React.FC<{ bounds: any }> = ({ bounds }) => {
  const map = useMap();
  
  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds);
    }
  }, [bounds, map]);

  return null;
};

interface Props {
  geoJson: FeatureCollection | null;
}

export const MapView: React.FC<Props> = ({ geoJson }) => {
  const getFeatureStyle = (feature: Feature) => {
    const type = feature.geometry.type;
    const baseStyle = {
      weight: 2,
      opacity: 0.8,
      fillOpacity: 0.4,
    };

    switch (type) {
      case 'Point':
        return { ...baseStyle, color: '#10B981', radius: 8 };
      case 'LineString':
        return { ...baseStyle, color: '#3B82F6' };
      case 'Polygon':
        return { ...baseStyle, color: '#8B5CF6', fillColor: '#8B5CF6' };
      case 'MultiLineString':
        return { ...baseStyle, color: '#F59E0B' };
      case 'MultiPolygon':
        return { ...baseStyle, color: '#EC4899', fillColor: '#EC4899' };
      default:
        return { ...baseStyle, color: '#6B7280' };
    }
  };

  const onEachFeature = (feature: Feature, layer: any) => {
    if (feature.properties) {
      const name = feature.properties.name || 'Unnamed feature';
      const description = feature.properties.description || 'No description available';
      layer.bindTooltip(`
        <div class="font-semibold">${name}</div>
        <div class="text-sm">${description}</div>
      `);
    }
  };

  const bounds = useMemo(() => {
    if (!geoJson || !geoJson.features.length) return undefined;

    let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;

    const updateBounds = (coord: Position) => {
      const [lng, lat] = coord;
      minLat = Math.min(minLat, lat);
      maxLat = Math.max(maxLat, lat);
      minLng = Math.min(minLng, lng);
      maxLng = Math.max(maxLng, lng);
    };

    const processCoordinates = (coords: any, type: string) => {
      switch (type) {
        case 'Point':
          updateBounds(coords as Position);
          break;
        case 'LineString':
          (coords as Position[]).forEach(updateBounds);
          break;
        case 'Polygon':
        case 'MultiLineString':
          (coords as Position[][]).forEach(line => line.forEach(updateBounds));
          break;
        case 'MultiPolygon':
          (coords as Position[][][]).forEach(poly => 
            poly.forEach(line => line.forEach(updateBounds))
          );
          break;
      }
    };

    geoJson.features.forEach(feature => {
      processCoordinates(feature.geometry.coordinates, feature.geometry.type);
    });

    // Add a small padding to the bounds
    const latPadding = (maxLat - minLat) * 0.1;
    const lngPadding = (maxLng - minLng) * 0.1;

    return [
      [minLat - latPadding, minLng - lngPadding],
      [maxLat + latPadding, maxLng + lngPadding]
    ];
  }, [geoJson]);

  // Generate a unique key for the GeoJSON component
  const geoJsonKey = useMemo(() => {
    return geoJson ? JSON.stringify(geoJson.features.map(f => f.geometry.coordinates)) : 'no-data';
  }, [geoJson]);

  return (
    <div className="w-full h-[600px] rounded-xl overflow-hidden shadow-lg">
      <MapContainer
        center={[0, 0]}
        zoom={2}
        className="w-full h-full"
        boundsOptions={{ padding: [50, 50] }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {geoJson && (
          <GeoJSON
            key={geoJsonKey}
            data={geoJson}
            style={getFeatureStyle}
            onEachFeature={onEachFeature}
          />
        )}
        <MapUpdater bounds={bounds} />
      </MapContainer>
    </div>
  );
};