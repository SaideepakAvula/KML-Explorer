import React from 'react';
import { KMLStats, DetailedStats } from '../types';
import { FileBarChart, FileLineChart, AlertCircle } from 'lucide-react';

interface Props {
  stats: KMLStats | null;
  detailedStats: DetailedStats | null;
  error: string | null;
  onSummaryClick: () => void;
  onDetailedClick: () => void;
}

export const StatsPanel: React.FC<Props> = ({
  stats,
  detailedStats,
  error,
  onSummaryClick,
  onDetailedClick,
}) => {
  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center gap-2 text-red-500">
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex gap-4 mb-6">
        <button
          onClick={onSummaryClick}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          <FileBarChart size={20} />
          Summary
        </button>
        <button
          onClick={onDetailedClick}
          className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
        >
          <FileLineChart size={20} />
          Detailed
        </button>
      </div>

      {stats && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">Element Count</h3>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(stats).map(([key, value]) => (
              <div key={key} className="bg-gray-50 p-4 rounded-lg">
                <span className="text-gray-600">{key}:</span>
                <span className="font-semibold ml-2">{value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {detailedStats && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Detailed Statistics</h3>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <span className="text-gray-600">Total Length:</span>
            <span className="font-semibold ml-2">
              {(detailedStats.totalLength / 1000).toFixed(2)} km
            </span>
          </div>

          {detailedStats.totalArea > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <span className="text-gray-600">Total Area:</span>
              <span className="font-semibold ml-2">
                {(detailedStats.totalArea / 1000000).toFixed(2)} km²
              </span>
            </div>
          )}

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Bounding Box</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-gray-600">North: </span>
                <span className="font-medium">{detailedStats.boundingBox.north.toFixed(6)}°</span>
              </div>
              <div>
                <span className="text-gray-600">South: </span>
                <span className="font-medium">{detailedStats.boundingBox.south.toFixed(6)}°</span>
              </div>
              <div>
                <span className="text-gray-600">East: </span>
                <span className="font-medium">{detailedStats.boundingBox.east.toFixed(6)}°</span>
              </div>
              <div>
                <span className="text-gray-600">West: </span>
                <span className="font-medium">{detailedStats.boundingBox.west.toFixed(6)}°</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};