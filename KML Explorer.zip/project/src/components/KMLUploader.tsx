import React, { useCallback, useState } from 'react';
import { Upload, AlertCircle } from 'lucide-react';
import { kml } from '@tmcw/togeojson';

interface Props {
  onKMLParsed: (geoJson: any, error?: string) => void;
}

export const KMLUploader: React.FC<Props> = ({ onKMLParsed }) => {
  const [isDragging, setIsDragging] = useState(false);

  const parseKML = useCallback((kmlText: string) => {
    try {
      const parser = new DOMParser();
      const kmlDoc = parser.parseFromString(kmlText, 'text/xml');
      
      // Check for parsing errors
      const parseError = kmlDoc.getElementsByTagName('parsererror');
      if (parseError.length > 0) {
        throw new Error('Invalid KML format');
      }

      const geoJson = kml(kmlDoc);
      
      // Validate GeoJSON structure
      if (!geoJson.features || !Array.isArray(geoJson.features)) {
        throw new Error('Invalid KML structure');
      }

      onKMLParsed(geoJson);
    } catch (error) {
      onKMLParsed(null, error instanceof Error ? error.message : 'Failed to parse KML file');
    }
  }, [onKMLParsed]);

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.kml')) {
      onKMLParsed(null, 'Please upload a valid KML file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => parseKML(e.target?.result as string);
    reader.onerror = () => onKMLParsed(null, 'Failed to read file');
    reader.readAsText(file);
  }, [parseKML]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.name.toLowerCase().endsWith('.kml')) {
      const event = { target: { files: [file] } } as unknown as React.ChangeEvent<HTMLInputElement>;
      handleFileUpload(event);
    } else {
      onKMLParsed(null, 'Please upload a valid KML file');
    }
  }, [handleFileUpload]);

  return (
    <div className="w-full">
      <label
        className={`
          flex flex-col items-center justify-center w-full h-40
          border-2 border-dashed rounded-xl cursor-pointer
          transition-all duration-200 ease-in-out
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 bg-gray-50 hover:bg-gray-100'
          }
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <Upload className={`w-12 h-12 mb-4 ${isDragging ? 'text-blue-500' : 'text-gray-400'}`} />
          <p className="mb-2 text-sm text-gray-600">
            <span className="font-semibold">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-gray-500">KML files only</p>
        </div>
        <input
          type="file"
          className="hidden"
          accept=".kml"
          onChange={handleFileUpload}
        />
      </label>
    </div>
  );
};