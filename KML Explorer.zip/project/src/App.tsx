import React, { useState, useCallback } from 'react';
import { KMLUploader } from './components/KMLUploader';
import { MapView } from './components/MapView';
import { StatsPanel } from './components/StatsPanel';
import { MapState, KMLStats, DetailedStats } from './types';
import { Map } from 'lucide-react';

function App() {
  const [mapState, setMapState] = useState<MapState>({
    geoJson: null,
    stats: null,
    detailedStats: null,
    error: null,
  });

  const handleKMLParsed = useCallback((geoJson: any, error?: string) => {
    setMapState({
      geoJson,
      stats: null,
      detailedStats: null,
      error: error || null,
    });
  }, []);

  const calculateStats = useCallback((): KMLStats => {
    if (!mapState.geoJson) return {} as KMLStats;
    
    const stats: KMLStats = {
      Placemark: 0,
      Point: 0,
      LineString: 0,
      Polygon: 0,
      MultiGeometry: 0,
    };

    mapState.geoJson.features.forEach((feature) => {
      stats.Placemark++;
      switch (feature.geometry.type) {
        case 'Point':
          stats.Point++;
          break;
        case 'LineString':
          stats.LineString++;
          break;
        case 'Polygon':
          stats.Polygon++;
          break;
        case 'MultiLineString':
        case 'MultiPolygon':
          stats.MultiGeometry++;
          break;
      }
    });

    return stats;
  }, [mapState.geoJson]);

  const calculateDetailedStats = useCallback((): DetailedStats => {
    const stats = calculateStats();
    let totalLength = 0;
    let totalArea = 0;
    let north = -90, south = 90, east = -180, west = 180;

    if (mapState.geoJson) {
      mapState.geoJson.features.forEach((feature) => {
        const coords = feature.geometry.coordinates;

        const processCoord = (coord: number[]) => {
          const [lng, lat] = coord;
          north = Math.max(north, lat);
          south = Math.min(south, lat);
          east = Math.max(east, lng);
          west = Math.min(west, lng);
        };

        switch (feature.geometry.type) {
          case 'LineString':
            for (let i = 1; i < coords.length; i++) {
              const [lon1, lat1] = coords[i - 1];
              const [lon2, lat2] = coords[i];
              totalLength += calculateDistance(lat1, lon1, lat2, lon2);
              processCoord([lon1, lat1]);
              processCoord([lon2, lat2]);
            }
            break;
          case 'Polygon':
            totalArea += calculatePolygonArea(coords[0]);
            coords[0].forEach(processCoord);
            break;
          case 'MultiLineString':
            coords.forEach((line: number[][]) => {
              for (let i = 1; i < line.length; i++) {
                const [lon1, lat1] = line[i - 1];
                const [lon2, lat2] = line[i];
                totalLength += calculateDistance(lat1, lon1, lat2, lon2);
                processCoord([lon1, lat1]);
                processCoord([lon2, lat2]);
              }
            });
            break;
          case 'MultiPolygon':
            coords.forEach((poly: number[][][]) => {
              totalArea += calculatePolygonArea(poly[0]);
              poly[0].forEach(processCoord);
            });
            break;
          case 'Point':
            processCoord(coords);
            break;
        }
      });
    }

    return {
      ...stats,
      totalLength,
      totalArea,
      boundingBox: { north, south, east, west },
    };
  }, [mapState.geoJson, calculateStats]);

  const handleSummaryClick = useCallback(() => {
    setMapState((prev) => ({
      ...prev,
      stats: calculateStats(),
      detailedStats: null,
      error: null,
    }));
  }, [calculateStats]);

  const handleDetailedClick = useCallback(() => {
    setMapState((prev) => ({
      ...prev,
      stats: null,
      detailedStats: calculateDetailedStats(),
      error: null,
    }));
  }, [calculateDetailedStats]);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Map className="w-8 h-8 text-blue-500" />
          <h1 className="text-3xl font-bold text-gray-800">KML Explorer</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <KMLUploader onKMLParsed={handleKMLParsed} />
            <MapView geoJson={mapState.geoJson} />
          </div>
          
          <div>
            <StatsPanel
              stats={mapState.stats}
              detailedStats={mapState.detailedStats}
              error={mapState.error}
              onSummaryClick={handleSummaryClick}
              onDetailedClick={handleDetailedClick}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// Haversine formula to calculate distance between two points
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// Calculate area of a polygon using the Shoelace formula
function calculatePolygonArea(coords: number[][]): number {
  let area = 0;
  const R = 6371e3; // Earth's radius in meters

  for (let i = 0; i < coords.length - 1; i++) {
    const [lon1, lat1] = coords[i];
    const [lon2, lat2] = coords[i + 1];
    
    // Convert to radians
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const λ1 = lon1 * Math.PI / 180;
    const λ2 = lon2 * Math.PI / 180;

    // Calculate area using spherical geometry
    area += (λ2 - λ1) * (2 + Math.sin(φ1) + Math.sin(φ2));
  }

  area = Math.abs(area * R * R / 2);
  return area;
}

export default App;